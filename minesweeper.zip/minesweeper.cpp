﻿#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <iostream>
#include <ctime>

int main()
{
	srand(time(0));
	const int WINDOW_WIDTH = 320;
	const int WINDOW_HEIGHT = 320;
	sf::Vector2f screenSpace(WINDOW_WIDTH, WINDOW_HEIGHT);

	const int fieldWidth = 10;
	const int fieldHeight = 10;

	int bombsAmount = 0;

	struct Shake {
		int intensity = 25;
		int lifetime = 180;

		float offset_x = 0.f;
		float offset_y = 0.f;
	};

	struct Explosion {
		float x = 0.f;
		float y = 0.f;

		float scale_x = 0.f;
		float scale_y = 0.f;

		float motion_x = 0.f;
		float motion_y = 0.f;

		bool shouldShrink = false;
	};

	struct Flash {
		int density = 220;
		int lifetime = 25;
	};

	Explosion explosion;
	Shake shake;
	Flash flash;

	sf::Clock gameClock;
	bool gameOver = false;
	bool cellPressed = false;

	// EFFECT's CLOCKS -------------------------------------------------------------------
	sf::Clock flashClock;
	sf::Clock shakeClock;
	sf::Clock explosionClock;

	sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "нень");

	sf::Texture tilesTexture;
	tilesTexture.loadFromFile("res/field/tiles.png");
	sf::Texture explosionTexture;
	explosionTexture.loadFromFile("res/hud/explosion.png");

	sf::Texture smileTexture;
	smileTexture.loadFromFile("res/hud/smile.png");

	sf::Sprite tiles(tilesTexture);
	sf::Sprite explosionObj(explosionTexture);
	sf::Sprite smile(smileTexture);

	sf::RectangleShape flashObj(screenSpace);

	sf::Font font;
	font.loadFromFile("res/fonts/JetBrainsMonoBold.ttf");

	sf::Text flagsCounterT;
	flagsCounterT.setFont(font);
	flagsCounterT.setFillColor(sf::Color::Red);

	sf::Text elapsedTimeT;
	elapsedTimeT.setFont(font);
	elapsedTimeT.setFillColor(sf::Color::Red);
	elapsedTimeT.setPosition(250, 0);
	elapsedTimeT.setString("0");

	flashObj.setScale(WINDOW_WIDTH, WINDOW_HEIGHT);

	smile.setPosition(320, 0);

	int field[fieldHeight + 2][fieldWidth + 2] = { 0 };
	int shownField[fieldHeight + 2][fieldWidth + 2] = { 0 };

	int gameOverField[fieldHeight + 2][fieldWidth + 2] = { 0 };

	//Empty or bomb
	for (int i = 1; i < fieldHeight + 1; i++)
	{
		for (int j = 1; j < fieldWidth + 1; j++)
		{
			shownField[i][j] = 10;

			if (rand() % 5 == 0) {
				field[i][j] = 9;
				bombsAmount += 1;
			}
			else {
				field[i][j] = 0;
			}
		}
	}

	//Number for mine detection
	for (int i = 1; i < fieldHeight + 1; i++)
	{
		for (int j = 1; j < fieldWidth + 1; j++)
		{
			if (field[i][j] != 9) {
				for (int k = -1; k < 2; k++)
				{
					for (int l = -1; l < 2; l++)
					{
						if(field[i + k][j + l] == 9) {
							field[i][j] += 1;
						}
					}
				}
			}
		}
	}

	int flagsCounter = bombsAmount;

	while (window.isOpen())
	{
		sf::Event event;

		sf::Vector2i pos = sf::Mouse::getPosition(window);
		int cell_x = pos.x / 32;
		int cell_y = pos.y / 32;

		sf::Time gameTime = gameClock.getElapsedTime();

		flagsCounterT.setString(std::to_string(flagsCounter));

		if (!gameOver && cellPressed) {
			elapsedTimeT.setString(std::to_string(gameTime.asSeconds()));
		}

		while (window.pollEvent(event))
		{

			if (event.type == sf::Event::MouseButtonPressed) {
				if (!gameOver) {
					if (event.key.code == sf::Mouse::Left) {
						if (shownField[cell_x][cell_y] == 10) {

							shownField[cell_x][cell_y] = field[cell_x][cell_y];

							if (field[cell_x][cell_y] == 9) {
								explosion.x = cell_x * 32 - 16;
								explosion.y = cell_y * 32 - 16;

								field[cell_x][cell_y] = 13;

								gameOver = true;
							}
						}
					}
					if (event.key.code == sf::Mouse::Right) {
						if (shownField[cell_x][cell_y] == 10 && flagsCounter > 0) {
							flagsCounter -= 1;
							shownField[cell_x][cell_y] = 11;
						}
						else if (shownField[cell_x][cell_y] == 11) {
							flagsCounter += 1;
							shownField[cell_x][cell_y] = 10;
						}
					}
					gameClock.restart();
					cellPressed = true;
				}
			}

			if (event.type == sf::Event::Closed)
				window.close();
		}

		for (int i = 1; i < fieldHeight + 1; i++)
		{
			for (int j = 1; j < fieldWidth + 1; j++)
			{
				if (field[i][j] != 9 && shownField[i][j] == 11) {
					gameOverField[i][j] = 12;
				}
				else if (field[i][j] == 9 && shownField[i][j] == 11) {
					gameOverField[i][j] = 11;
				}
				else {
					gameOverField[i][j] = field[i][j];
				}
			}
		}

		// ON GAME OVER -----------------------------------------------------------------------------------------

		if (gameOver) {
			sf::Time flashTime = flashClock.getElapsedTime();
			sf::Time shakeTime = shakeClock.getElapsedTime();
			sf::Time explosionTime = explosionClock.getElapsedTime();

			if (shakeTime.asMilliseconds() >= 25 && shake.intensity > 0) {
				shake.offset_x = rand() % shake.intensity - shake.intensity / 2;
				shake.offset_y = rand() % shake.intensity - shake.intensity / 2;

				if (shakeTime.asMilliseconds() >= shake.lifetime) {
					shake.intensity -= 1;
					shakeClock.restart();
				}
			}

			if (explosionTime.asMilliseconds() >= 25) {
				if (explosion.scale_x < 8 && !explosion.shouldShrink) {
					explosion.scale_x += 0.2;
					explosion.scale_y += 0.2;
				}
				else if (explosion.scale_x > 0) {
					explosion.scale_x -= 0.05;
					explosion.scale_y -= 0.05;
				}

				if (explosion.scale_x >= 8) {
					explosion.shouldShrink = true;
				}

				explosionClock.restart();
			}

			if (flashTime.asMilliseconds() >= flash.lifetime && flash.density > 0) {
				flash.density -= 1;
				flashClock.restart();
			}

		}


		// RENDER -----------------------------------------------------------------------------------------------
		window.clear();

		// INGAME -----------------------------------------------------------------------------------------------

		for (int i = 0; i < fieldWidth + 1; i++)
		{
			for (int j = 0; j < fieldHeight + 1; j++)
			{
				int tileId = rand() % 12;
				if (!gameOver) {
					tiles.setTextureRect(sf::IntRect(32 * shownField[i + 1][j + 1], 0, 32, 32));
				}
				else {
					tiles.setTextureRect(sf::IntRect(32 * gameOverField[i + 1][j + 1], 0, 32, 32));
				}
				tiles.setPosition(i * 32 + shake.offset_x, j * 32 + shake.offset_y);
				window.draw(tiles);

				//Logs the mouse coordinates
				//std::cout << cell_x << "; " << cell_y << "\n";
			}
		}

		// ON GAME OVER -----------------------------------------------------------------------------------------

		if (gameOver) {
			explosionObj.setOrigin(32, 32);
			explosionObj.setPosition(explosion.x + 32, explosion.y + 32);
			explosionObj.setScale(explosion.scale_x, explosion.scale_y);

			flashObj.setPosition(0, 0);
			flashObj.setFillColor(sf::Color(255, 233, 173, flash.density));

			window.draw(explosionObj);
			window.draw(flashObj);
		}
		
		window.draw(elapsedTimeT);
		window.draw(flagsCounterT);
		window.draw(smile);

		window.display();
		// RENDER END ------------------------------------------------------------------------------------------
	}
	return 0;
}